# cryptocurrency-course-materials
Additional materials related to Bitcoin and Cryptocurrency Technologies course on Coursera, maintained by the mentors of that course.
